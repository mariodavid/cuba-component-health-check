CREATE procedure SET_SEQ_VAL(seqname varchar2, newvalue number)
as
    ln number;
    ib number;
begin
    select LAST_NUMBER, INCREMENT_BY
    into ln, ib
    from USER_SEQUENCES
    where SEQUENCE_NAME = upper(seqname);
    execute immediate 'alter sequence ' || seqname || ' increment by ' || (newvalue - ln);
    execute immediate 'select ' || seqname || '.nextval from dual' into ln;
    execute immediate 'alter sequence ' || seqname || ' increment by ' || ib;
end;
/
